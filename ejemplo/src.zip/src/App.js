import React, { useState } from 'react';
import { ChakraProvider } from '@chakra-ui/react';
import { ThemeProvider as MUIThemeProvider, createTheme } from '@mui/material/styles';
import Header from './components/Header/header';
import Sidebar from './components/Siderbar/Sidebar';
import UserTable from './components/UserTable'; // Importar el nuevo componente
import Breadcrumbs from './components/Breadcrumbs'; // Importar el componente Breadcrumbs
import './App.css'; 

const theme = createTheme(); // Crear un tema para Material-UI

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(true); // Estado para controlar el Sidebar
  const [activeView, setActiveView] = useState(''); // Estado para controlar la vista activa
  const [breadcrumbs, setBreadcrumbs] = useState([]); // Estado para almacenar los breadcrumbs
  const [pageTitle, setPageTitle] = useState(''); // Estado para el título de la página
  const [usuarios, setUsuarios] = useState([]); // Estado para almacenar los datos de usuarios

  // Función para alternar el estado del Sidebar
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  // Función para cambiar la vista activa y configurar el título y los breadcrumbs
  const handleViewChange = (view, title, breadcrumbs) => {
    setActiveView(view);
    setPageTitle(title);
    setBreadcrumbs(breadcrumbs);
    if (view === 'usuarios' && usuarios.length === 0) {
      fetchUsuarios(); // Cargar los datos de usuarios si la vista es 'usuarios' y aún no se han cargado
    }
  };

  // Función para obtener los datos de la tabla 'user' usando fetch
  const fetchUsuarios = () => {
    fetch('http://localhost:3001/api/usuarios') // Asegúrate de que tu backend esté corriendo en este puerto
      .then(response => {
        if (!response.ok) {
          throw new Error('Error en la respuesta del servidor');
        }
        return response.json();
      })
      .then(data => {
        setUsuarios(data); // Almacena los datos en el estado 'usuarios'
      })
      .catch(error => {
        console.error('Error al obtener los usuarios:', error);
      });
  };

  return (
    <ChakraProvider>
      <MUIThemeProvider theme={theme}>
        <Header toggleSidebar={toggleSidebar} />
        <div style={{ marginTop: '70px', display: 'flex' }}>
          <Sidebar isOpen={sidebarOpen} onViewChange={handleViewChange} activeView={activeView} />
          <div
            style={{
              flex: 1,
              padding: 20,
              marginLeft: sidebarOpen ? '240px' : '80px',
              transition: 'margin 0.3s ease',
            }}
          >
            <Breadcrumbs title={pageTitle} breadcrumbs={breadcrumbs} /> {/* Mostrar los breadcrumbs y el título */}
            <div className="contenedor-principal" style={{
              backgroundColor: '#EEF2F6',
              borderRadius: '8px',
              padding: '20px',
              marginBottom: '20px',
              minHeight: '600px',
            }}>
              {/* Vista dinámica según el estado activeView */}
              {activeView === 'usuarios' ? (
                <UserTable usuarios={usuarios} /> // Usar el nuevo componente UserTable
              ) : (
                <h1>Contenido Principal</h1>
              )}
            </div>
          </div>
        </div>
      </MUIThemeProvider>
    </ChakraProvider>
  );
}

export default App;
