// src/components/Header.js
import React, { useState } from 'react';
import BadgeAvatars from './badgeAvatars';
import SearchBar from './searchBar';

import {
  Box,
  HStack,
  IconButton,
  Input,
  InputGroup,
  InputLeftElement,
  useColorModeValue,
  useBreakpointValue,
  Collapse,
  Text,
} from '@chakra-ui/react';
import { Tune, Search, Settings, Notifications, Menu, Chat } from '@mui/icons-material';

const Header = ({ toggleSidebar }) => { // Recibe la función toggleSidebar como prop
  const [searchOpen, setSearchOpen] = useState(false);
  const showSearchFull = useBreakpointValue({ base: false, lg: true });

  return (
    <>
      <Box
        bg={useColorModeValue('white', 'gray.900')}
        px={4}
        py={2}
       
        position="fixed"
        w="full"
        top="0"
        left="0"
        zIndex="1"
      >
        <HStack justifyContent="space-between" alignItems="center">
          {/* Logo y Botón del Menú */}
          <HStack spacing={5} alignItems="center">
            <Text fontSize="xl" fontWeight="bold" color="black" pr="70px">SAG</Text>
            <IconButton
              aria-label="Menu"
              icon={<Menu fontSize="small" />}
              onClick={toggleSidebar} // Llama a la función para alternar el Sidebar
              variant="ghost"
              sx={{
                color: '#6E40C9',
                bg: 'rgba(106, 39, 196, 0.1)',
                _hover: {
                  bg: 'rgba(106, 39, 196, 0.3)',
                },
                _active: {
                  bg: 'rgba(106, 39, 196, 0.5)',
                },
                borderRadius: '10px',
                padding: '6px',
              }}
            />

            {/* Barra de Búsqueda */}
            {showSearchFull ? (
              <SearchBar /> // Aquí usamos el componente SearchBar
            ) : (
              <IconButton
                aria-label="Search"
                icon={<Search fontSize="small" />}
                variant="ghost"
                onClick={() => setSearchOpen(!searchOpen)}
                sx={{
                  color: '#6E40C9',
                  bg: 'rgba(106, 39, 196, 0.1)',
                  _hover: {
                    bg: 'rgba(106, 39, 196, 0.3)',
                  },
                  _active: {
                    bg: 'rgba(106, 39, 196, 0.5)',
                  },
                  borderRadius: '10px',
                  padding: '6px',
                }}
              />
            )}
          </HStack>

          {/* Iconos de Notificaciones y Configuración */}
          <HStack spacing={4} alignItems="center">
            <IconButton
              aria-label="Notifications"
              icon={<Notifications fontSize="small" />}
              variant="ghost"
              sx={{
                color: '#6E40C9',
                bg: 'rgba(106, 39, 196, 0.1)',
                _hover: {
                  bg: 'rgba(106, 39, 196, 0.3)',
                },
                _active: {
                  bg: 'rgba(106, 39, 196, 0.5)',
                },
                borderRadius: '10px',
                padding: '6px',
              }}
            />
            <IconButton
              aria-label="Chat"
              icon={<Chat fontSize="small" />}
              variant="ghost"
              sx={{
                color: '#6E40C9',
                bg: 'rgba(106, 39, 196, 0.1)',
                _hover: {
                  bg: 'rgba(106, 39, 196, 0.3)',
                },
                _active: {
                  bg: 'rgba(106, 39, 196, 0.5)',
                },
                borderRadius: '10px',
                padding: '6px',
              }}
            />
            <IconButton
              aria-label="Settings"
              icon={<Settings fontSize="small" />}
              variant="ghost"
              sx={{
                color: '#6E40C9',
                bg: 'rgba(106, 39, 196, 0.1)',
                _hover: {
                  bg: 'rgba(106, 39, 196, 0.3)',
                },
                _active: {
                  bg: 'rgba(106, 39, 196, 0.5)',
                },
                borderRadius: '10px',
                padding: '6px',
              }}
            />
            <BadgeAvatars /> {/* Usa el avatar personalizado aquí */}
          </HStack>
        </HStack>

        {/* Barra de Búsqueda Colapsada */}
        {!showSearchFull && (
          <Collapse in={searchOpen} animateOpacity>
            <InputGroup mt={5} w="full">
              <InputLeftElement
                pointerEvents="none"
                children={<Search style={{ fontSize: 28, color: "#9e9e9e" }} />}  // Reducir el tamaño del icono
              />
              <Input
                type="text"
                placeholder="Search users..."
                border="none" // Sin borde para un diseño limpio
                _focus={{
                  outline: "none", // Sin borde de selección
                  boxShadow: 'none', // Sin sombra al hacer foco
                }}
                _placeholder={{
                  color: 'gray.500', // Color del placeholder
                }}
                h="30px" // Altura del input
                pl="50px" // Espaciado a la izquierda del texto
                pr="270px" // Espaciado a la derecha para evitar el solapamiento con el icono
                bg="transparent" // Fondo transparente
              />
              <IconButton
                aria-label="Filter"
                icon={<Tune style={{ fontSize: 22 }} />} // Tamaño del icono de filtro ajustado
                borderRadius="lg" // Bordes redondeados
                position="absolute" // Posicionamiento absoluto para alinear a la derecha
                right="0" // Alinear a la derecha
                mt="-10px" // Margen superior para centrar verticalmente
                mr="10px" // Margen derecho
                h="40px"// Altura del botón de filtro
                w="40px"
                bg="rgba(139, 92, 246, 0.1)" // Color de fondo claro
                _hover={{
                  color: 'rgba(255, 255, 255)',
                  bg: 'rgba(139, 92, 246, 0.3)', // Fondo más oscuro al pasar el cursor
                }}
                _active={{
                  bg: 'rgba(139, 92, 246, 0.5)', // Fondo más oscuro al hacer clic
                }}
              />
            </InputGroup>
          </Collapse>
        )}
      </Box>
    </>
  );
};

export default Header;
